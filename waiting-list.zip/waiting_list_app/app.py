from flask import Flask, render_template, request, redirect, url_for, jsonify

app = Flask(__name__)

# Initialize data with 100 stations, numbered 1 to 100
stations = {str(i): [] for i in range(1, 101)}  # Changed from "Station 1" to just "1"

def sort_waiting_list(waiting_list):
    return sorted(waiting_list, key=lambda x: not x['vip'])

@app.route('/')
def index():
    stations_list = list(stations.keys())
    return render_template('index.html', stations=stations_list)

@app.route('/operator', methods=['GET', 'POST'])
def operator():
    if request.method == 'POST':
        station = request.form.get('station')
        action = request.form.get('action')
        name = request.form.get('name')
        vip = request.form.get('vip') == 'on'
        if action == 'add' and name:
            stations[station].append({'name': name, 'vip': vip})
            stations[station] = sort_waiting_list(stations[station])
        elif action == 'remove':
            stations[station] = [person for person in stations[station] if person['name'] != name]
        elif action == 'edit' and name:
            old_name = request.form.get('old_name')
            for person in stations[station]:
                if person['name'] == old_name:
                    person['name'] = name
                    person['vip'] = vip
            stations[station] = sort_waiting_list(stations[station])
        elif action == 'reorder':
            stations[station] = sort_waiting_list(stations[station])
        return redirect(url_for('operator', station=station))
    station = request.args.get('station', '1')  # Default to station '1'
    return render_template('operator.html', station=station, waiting_list=stations[station])

@app.route('/display')
def display():
    station = request.args.get('station', '1')  # Default to station '1'
    return render_template('display.html', station=station, waiting_list=stations[station])

@app.route('/api/waiting_list/<station>')
def api_waiting_list(station):
    return jsonify(stations[station])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)
