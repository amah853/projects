import sqlite3

def create_auth_db():
    # Connect to the SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect('auth.db')
    cursor = conn.cursor()

    # Create the users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')

    # Insert default admin user with predefined username and password
    # Note: The password is hashed using SHA-256 in practice, this is a placeholder
    # The admin password is hashed as SHA-256 of "PASSWORD"
    default_password = 'PASSWORD'
    hashed_password = hashlib.sha256(default_password.encode()).hexdigest()

    cursor.execute('''
        INSERT INTO users (username, password, role)
        VALUES (?, ?, ?)
    ''', ('admin', hashed_password, 'manager'))

    # Commit the transaction
    conn.commit()
    conn.close()

if __name__ == '__main__':
    import hashlib
    create_auth_db()
    print("Authentication database created and default admin user added.")
