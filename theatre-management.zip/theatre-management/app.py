from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = 'supersecretkey'

login_manager = LoginManager()
login_manager.login_view = 'login'  # Redirect to login if not authenticated
login_manager.init_app(app)

def get_auth_db_connection():
    conn = sqlite3.connect('auth.db')
    conn.row_factory = sqlite3.Row
    return conn

def get_theater_db_connection():
    conn = sqlite3.connect('movie_theater.db')
    conn.row_factory = sqlite3.Row
    return conn

class User(UserMixin):
    def __init__(self, id, username, role):
        self.id = id
        self.username = username
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    conn = get_auth_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if user:
        return User(user['id'], user['username'], user['role'])
    return None

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_auth_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                            (username, hashlib.sha256(password.encode()).hexdigest())).fetchone()
        conn.close()

        if user:
            login_user(User(user['id'], user['username'], user['role']))
            return redirect(url_for('index'))

        return render_template('login.html', error='Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/manage_users', methods=['GET', 'POST'])
@login_required
def manage_users():
    if current_user.role != 'manager':
        return 'Access denied', 403

    if request.method == 'POST':
        action = request.form['action']
        username = request.form['username']
        password = request.form['password']
        role = request.form.get('role', 'staff')

        conn = get_auth_db_connection()

        if action == 'add':
            conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                         (username, hashlib.sha256(password.encode()).hexdigest(), role))
        elif action == 'update':
            user_id = request.form['user_id']
            conn.execute('UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?',
                         (username, hashlib.sha256(password.encode()).hexdigest(), role, user_id))
        elif action == 'delete':
            conn.execute('DELETE FROM users WHERE username = ?', (username,))

        conn.commit()
        conn.close()

    conn = get_auth_db_connection()
    users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()

    return render_template('manage_users.html', users=users)

@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        new_password = request.form['new_password']
        conn = get_auth_db_connection()
        conn.execute('UPDATE users SET password = ? WHERE id = ?',
                     (hashlib.sha256(new_password.encode()).hexdigest(), current_user.id))
        conn.commit()
        conn.close()
        return redirect(url_for('logout'))
    return render_template('change_password.html')

@app.route('/box_office')
@login_required
def box_office():
    return render_template('box_office.html')

@app.route('/pass_checker')
@login_required
def pass_checker():
    return render_template('pass_checker.html')

@app.route('/manager')
@login_required
def manager():
    return render_template('manager.html')

@app.route('/get_movies')
@login_required
def get_movies():
    conn = get_theater_db_connection()
    movies = conn.execute('SELECT * FROM movies').fetchall()
    conn.close()
    return jsonify([dict(movie) for movie in movies])

@app.route('/assign_tag', methods=['POST'])
@login_required
def assign_tag():
    data = request.json
    tag_number = data['tag_number']
    movie_id = data['movie_id']
    override = data.get('override', False)

    conn = get_theater_db_connection()
    cursor = conn.cursor()

    existing_tag = cursor.execute('SELECT * FROM rfid_tags WHERE tag_number = ?', (tag_number,)).fetchone()

    if existing_tag:
        if override:
            cursor.execute('UPDATE rfid_tags SET movie_id = ? WHERE tag_number = ?', (movie_id, tag_number))
        else:
            conn.close()
            return jsonify({'status': 'error', 'message': 'Tag already assigned to another movie'}), 400
    else:
        cursor.execute('INSERT INTO rfid_tags (tag_number, movie_id) VALUES (?, ?)', (tag_number, movie_id))
    
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/check_tag', methods=['POST'])
@login_required
def check_tag():
    data = request.json
    movie_id = data['movie_id']
    tag_number = data['tag_number']

    conn = get_theater_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT movies.id, movies.name FROM rfid_tags 
        JOIN movies ON rfid_tags.movie_id = movies.id 
        WHERE rfid_tags.tag_number = ?
    """, (tag_number,))
    result = cursor.fetchone()

    conn.close()

    if result:
        assigned_movie_id, assigned_movie_name = result
        if assigned_movie_id == int(movie_id):
            return jsonify({"message": "Access Granted", "movie_name": assigned_movie_name}), 200
        else:
            return jsonify({"message": "Access Denied", "movie_name": assigned_movie_name}), 400
    else:
        return jsonify({"message": "Tag not found or not assigned to any movie."}), 404

@app.route('/end_movie', methods=['POST'])
@login_required
def end_movie():
    movie_id = request.json['movie_id']

    conn = get_theater_db_connection()
    conn.execute('DELETE FROM rfid_tags WHERE movie_id = ?', (movie_id,))
    conn.commit()
    conn.close()

    return jsonify({'status': 'success'})

@app.route('/manager_action', methods=['POST'])
@login_required
def manager_action():
    action = request.json['action']
    conn = get_theater_db_connection()

    if action == 'add_movie':
        movie_name = request.json['movie_name']
        conn.execute('INSERT INTO movies (name) VALUES (?)', (movie_name,))
    elif action == 'remove_movie':
        movie_id = request.json['movie_id']
        conn.execute('DELETE FROM movies WHERE id = ?', (movie_id,))
        conn.execute('DELETE FROM rfid_tags WHERE movie_id = ?', (movie_id,))
    elif action == 'end_all_movies':
        conn.execute('DELETE FROM rfid_tags')

    conn.commit()
    conn.close()

    return jsonify({'status': 'success'})

@app.route('/check_tag_manager', methods=['POST'])
@login_required
def check_tag_manager():
    data = request.json
    tag_number = data['tag_number']

    conn = get_theater_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT movies.name FROM rfid_tags 
        JOIN movies ON rfid_tags.movie_id = movies.id 
        WHERE rfid_tags.tag_number = ?
    """, (tag_number,))
    result = cursor.fetchone()

    conn.close()

    if result:
        movie_name = result[0]
        return jsonify({"movie_name": movie_name}), 200
    else:
        return jsonify({"message": "Tag not found or not assigned to any movie."}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
