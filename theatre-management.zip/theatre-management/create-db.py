import sqlite3

def init_db():
    conn = sqlite3.connect('movie_theater.db')
    cursor = conn.cursor()

    # Create movies table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS movies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL
    )
    ''')

    # Create RFID tags table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS rfid_tags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tag_number TEXT NOT NULL UNIQUE,
        movie_id INTEGER,
        FOREIGN KEY (movie_id) REFERENCES movies(id)
    )
    ''')

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
