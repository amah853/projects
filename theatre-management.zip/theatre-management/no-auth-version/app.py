from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

# Helper function to connect to the database
def get_db_connection():
    conn = sqlite3.connect('movie_theater.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/box_office')
def box_office():
    return render_template('box_office.html')

@app.route('/pass_checker')
def pass_checker():
    return render_template('pass_checker.html')

@app.route('/manager')
def manager():
    return render_template('manager.html')

@app.route('/get_movies')
def get_movies():
    conn = get_db_connection()
    movies = conn.execute('SELECT * FROM movies').fetchall()
    conn.close()
    return jsonify([dict(movie) for movie in movies])

@app.route('/assign_tag', methods=['POST'])
def assign_tag():
    data = request.json
    tag_number = data['tag_number']
    movie_id = data['movie_id']

    conn = get_db_connection()
    cursor = conn.cursor()

    existing_tag = cursor.execute('SELECT * FROM rfid_tags WHERE tag_number = ?', (tag_number,)).fetchone()

    if existing_tag:
        if data.get('override'):
            cursor.execute('UPDATE rfid_tags SET movie_id = ? WHERE tag_number = ?', (movie_id, tag_number))
        else:
            conn.close()
            return jsonify({'status': 'error', 'message': 'Tag already assigned to another movie'}), 400
    else:
        cursor.execute('INSERT INTO rfid_tags (tag_number, movie_id) VALUES (?, ?)', (tag_number, movie_id))
    
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/check_tag', methods=['POST'])
def check_tag():
    data = request.json
    movie_id = data['movie_id']
    tag_number = data['tag_number']

    conn = sqlite3.connect('movie_theater.db')
    cursor = conn.cursor()
    
    # Check if the tag is assigned to any movie
    cursor.execute("""
        SELECT movies.id, movies.name FROM rfid_tags 
        JOIN movies ON rfid_tags.movie_id = movies.id 
        WHERE rfid_tags.tag_number = ?
    """, (tag_number,))
    result = cursor.fetchone()

    conn.close()

    if result:
        assigned_movie_id, assigned_movie_name = result
        if assigned_movie_id == int(movie_id):
            return jsonify({"movie_name": assigned_movie_name}), 200
        else:
            return jsonify({"movie_name": assigned_movie_name}), 400
    else:
        return jsonify({"message": "Tag not found or not assigned to any movie."}), 404

@app.route('/end_movie', methods=['POST'])
def end_movie():
    movie_id = request.json['movie_id']

    conn = get_db_connection()
    conn.execute('DELETE FROM rfid_tags WHERE movie_id = ?', (movie_id,))
    conn.commit()
    conn.close()

    return jsonify({'status': 'success'})

@app.route('/manager_action', methods=['POST'])
def manager_action():
    action = request.json['action']
    conn = get_db_connection()

    if action == 'add_movie':
        movie_name = request.json['movie_name']
        conn.execute('INSERT INTO movies (name) VALUES (?)', (movie_name,))
    elif action == 'remove_movie':
        movie_id = request.json['movie_id']
        conn.execute('DELETE FROM movies WHERE id = ?', (movie_id,))
        conn.execute('DELETE FROM rfid_tags WHERE movie_id = ?', (movie_id,))
    elif action == 'end_all_movies':
        conn.execute('DELETE FROM rfid_tags')

    conn.commit()
    conn.close()

    return jsonify({'status': 'success'})

@app.route('/check_tag_manager', methods=['POST'])
def check_tag_manager():
    data = request.json
    tag_number = data['tag_number']

    conn = sqlite3.connect('movie_theater.db')
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT movies.name FROM rfid_tags 
        JOIN movies ON rfid_tags.movie_id = movies.id 
        WHERE rfid_tags.tag_number = ?
    """, (tag_number,))
    result = cursor.fetchone()

    conn.close()

    if result:
        movie_name = result[0]
        return jsonify({"movie_name": movie_name}), 200
    else:
        return jsonify({"message": "Tag not found or not assigned to any movie."}), 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
