import sqlite3

DATABASE = 'arcade.db'

def initialize_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Create tables
    cursor.executescript('''
        -- Create the 'games' table
        CREATE TABLE IF NOT EXISTS games (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL
        );

        -- Create the 'cards' table
        CREATE TABLE IF NOT EXISTS cards (
            card_number TEXT PRIMARY KEY,
            money REAL NOT NULL DEFAULT 0,
            tickets INTEGER NOT NULL DEFAULT 0
        );

        -- Create the 'orders' table
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            card_number TEXT,
            game_id INTEGER,
            amount REAL,
            tickets INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (card_number) REFERENCES cards(card_number),
            FOREIGN KEY (game_id) REFERENCES games(id)
        );
    ''')

    conn.commit()
    conn.close()

if __name__ == '__main__':
    initialize_db()
