from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
from datetime import datetime

app = Flask(__name__)

DATABASE = 'arcade.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/manager', methods=['GET', 'POST'])
def manager():
    if request.method == 'POST':
        if 'add_game' in request.form:
            name = request.form['name']
            price = request.form['price']
            conn = get_db()
            conn.execute('INSERT INTO games (name, price) VALUES (?, ?)', (name, price))
            conn.commit()
            conn.close()
        elif 'configure_game' in request.form:
            game_id = request.form['game_id']
            name = request.form['name']
            price = request.form['price']
            conn = get_db()
            conn.execute('UPDATE games SET name = ?, price = ? WHERE id = ?', (name, price, game_id))
            conn.commit()
            conn.close()
        elif 'delete_game' in request.form:
            game_id = request.form['game_id']
            conn = get_db()
            conn.execute('DELETE FROM games WHERE id = ?', (game_id,))
            conn.commit()
            conn.close()
        return redirect(url_for('manager'))
    else:
        conn = get_db()
        games = conn.execute('SELECT * FROM games').fetchall()
        conn.close()
        return render_template('manager.html', games=games)

@app.route('/games', methods=['GET', 'POST'])
def games():
    if request.method == 'POST':
        data = request.get_json()
        game_id = data['gameId']
        card_number = data['cardNumber']
        amount = float(data['amount'])
        tickets_to_add = int(data['tickets'])
        
        conn = get_db()
        game = conn.execute('SELECT * FROM games WHERE id = ?', (game_id,)).fetchone()
        card = conn.execute('SELECT * FROM cards WHERE card_number = ?', (card_number,)).fetchone()

        if card:
            card_balance = {'tickets': card['tickets'], 'money': card['money']}
            
            # Simulate payment processing
            if amount <= card_balance['money']:
                card_balance['money'] -= amount
                success = True
                message = 'Payment successful!'
                order_id = conn.execute('INSERT INTO orders (card_number, game_id, amount, tickets, timestamp) VALUES (?, ?, ?, ?, ?)',
                                        (card_number, game_id, amount, tickets_to_add, datetime.now())).lastrowid
                conn.execute('UPDATE cards SET money = ? WHERE card_number = ?', (card_balance['money'], card_number))
                conn.commit()
            else:
                success = False
                message = 'Payment failure, not enough money.'
                order_id = None

            # Add tickets if payment was successful
            if success and tickets_to_add > 0:
                card_balance['tickets'] += tickets_to_add
                conn.execute('UPDATE cards SET tickets = ? WHERE card_number = ?', (card_balance['tickets'], card_number))
                message += f' {tickets_to_add} tickets added.'
            
            conn.close()
            
            return jsonify({
                'success': success,
                'balance': card_balance,
                'message': message,
                'orderId': order_id,
                'gameName': game['name'] if game else 'Unknown'
            })
        else:
            return jsonify({'success': False, 'message': 'Card not found'})
    return render_template('games.html')

@app.route('/prizes', methods=['GET', 'POST'])
def prizes():
    if request.method == 'POST':
        data = request.get_json()
        card_number = data['cardNumber']
        tickets_to_charge = int(data['tickets'])
        
        conn = get_db()
        card = conn.execute('SELECT * FROM cards WHERE card_number = ?', (card_number,)).fetchone()

        if card:
            current_balance = {'tickets': card['tickets']}
            
            # Simulate ticket deduction
            if tickets_to_charge <= current_balance['tickets']:
                current_balance['tickets'] -= tickets_to_charge
                success = True
                message = 'Tickets deducted successfully!'
                conn.execute('UPDATE cards SET tickets = ? WHERE card_number = ?', (current_balance['tickets'], card_number))
                conn.commit()
            else:
                success = False
                message = 'Insufficient tickets.'
        else:
            success = False
            message = 'Card not found.'
        
        conn.close()

        return jsonify({
            'success': success,
            'balance': current_balance,
            'message': message
        })
    return render_template('prizes.html')

@app.route('/front_desk', methods=['GET', 'POST'])
def front_desk():
    if request.method == 'POST':
        if 'add_card' in request.form:
            card_number = request.form['card_number']
            starting_money = request.form['starting_money']
            starting_tickets = request.form['starting_tickets']
            conn = get_db()
            try:
                conn.execute('INSERT INTO cards (card_number, money, tickets) VALUES (?, ?, ?)', (card_number, starting_money, starting_tickets))
                conn.commit()
                message = 'Card added successfully!'
            except sqlite3.IntegrityError:
                message = 'Card already exists.'
            conn.close()
            return render_template('front_desk.html', message=message)
        elif 'remove_card' in request.form:
            card_number = request.form['card_number']
            conn = get_db()
            conn.execute('DELETE FROM cards WHERE card_number = ?', (card_number,))
            conn.commit()
            conn.close()
            return render_template('front_desk.html', message='Card removed successfully!')
        elif 'check_balance' in request.form:
            card_number = request.form['card_number']
            conn = get_db()
            card = conn.execute('SELECT * FROM cards WHERE card_number = ?', (card_number,)).fetchone()
            conn.close()
            if card:
                message = f"Card Balance - Money: ${card['money']}, Tickets: {card['tickets']}"
            else:
                message = 'Card not found.'
            return render_template('front_desk.html', message=message)
    return render_template('front_desk.html')

@app.route('/games/get_games', methods=['GET'])
def get_games():
    conn = get_db()
    games = conn.execute('SELECT * FROM games').fetchall()
    conn.close()
    games_list = [{'id': game['id'], 'name': game['name'], 'price': game['price']} for game in games]
    return jsonify(games_list)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)
